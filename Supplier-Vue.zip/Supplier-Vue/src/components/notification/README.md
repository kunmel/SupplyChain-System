# 自定义组件

一个自定义的 notification 插件。
支持模版以及api的调用方式