import request from '@/utils/request'

// 获取登录界面角色选择列表
export function queryAccountList() {
  return request({
    url: '/api/v1/queryAccountList',
    method: 'post'
  })
  // return request({
  //   url: '/accountlist.json',
  //   method: 'get'
  // })
}

// 登录
export function login(data) {
  // return request({
  //   url: '/queryAccountList',
  //   method: 'post',
  //   data
  // })
  return request({
    url: '../../web/accountlist.json',
    method: 'get',
    data
  })
}
