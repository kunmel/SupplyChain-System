/**
 * 字典集
 */

export const skills = ['Vue', 'Node', 'Spring', 'React', 'Flutter', '小程序']
