<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
@import 'normalize.css/normalize.css';
@import './style/index.css';
@import './style/custom.css';
</style>
