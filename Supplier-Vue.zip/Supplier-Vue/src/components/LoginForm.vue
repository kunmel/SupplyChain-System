<template>
<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm sign-in-form">
  <el-form-item label="用户名" prop="username">
    <el-input v-model="ruleForm.username"></el-input>
  </el-form-item>
   <el-form-item label="密码" prop="userpass">
    <el-input type="password" v-model="ruleForm.userpass" autocomplete="off"></el-input>
  </el-form-item>
    <el-form-item label="用户类型" prop="usertype">
    <el-radio-group v-model="ruleForm.usertype">
      <el-radio label="企业"></el-radio>
      <el-radio label="供应商"></el-radio>
    </el-radio-group>
  </el-form-item>
    <el-form-item>
    <el-button type="primary" @click="submitForm('ruleForm')">立即登陆</el-button>
    <el-button>取消</el-button>
  </el-form-item>

</el-form>	
</template>
<script>
import { queryAccountList } from '@/api/account'
import { saveToLocal, loadFromLocal } from '@/common/local-storage'
import { mapActions } from 'vuex'

  export default {
    data() {
		var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.ruleForm.checkPass !== '') {
            this.$refs.ruleForm.validateField('checkPass');
          }
          callback();
        }
      };
      return {
		loading: false,
		accountList:[],
		redirect:'',
        ruleForm: {
          username: '',
          userpass:'',
		      usertype: '',
        },
        rules: {
          username: [
            { required: true, message: '请输入用户名', trigger: 'blur' },
            { min: 3, max: 10, message: 'Length should be 3 to 10', trigger: 'blur' }
          ],
		    userpass: [
			{ required: true,  trigger: 'blur' },
            { validator: validatePass, trigger: 'blur' }
          ],
		     usertype: [
            { required: true, message: '请选择用户类别', trigger: 'change' }
          ],
        }
      };
    },
	  //监听路由
  watch: {
    $route: {
      handler: function(route) {
        this.redirect = route.query && route.query.redirect
        console.log("动态监听路由：")
        console.log(route.query)
      },
      immediate: true
    }
  },
	created() {
    	queryAccountList().then(response => {
        this.accountList = response
        console.log("AccountList")
        console.log(response)
      })

  },
    methods: {
    ...mapActions([
      'login'
    ]),
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            // alert('submit!');
			      // this.handleLogin()
            if (this.ruleForm.usertype  == "供应商"){
              this.loading = true
              this.login(this.ruleForm).then(() => {
                // 保存账号
                if (this.remember) {
                  saveToLocal('username', this.ruleForm.username)
                  saveToLocal('password', this.ruleForm.userpass)
                  saveToLocal('remember', true)
                } else {
                  saveToLocal('username', '')
                  saveToLocal('password', '')
                  saveToLocal('remember', false)
                }
                this.$router.push({ path: '/home' })
              }).catch(() => {
                this.loading = false
              })
            } else{     
                alert("进入企业界面")
                this.$router.push({ path: '/company' })
            }
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      },

	handleLogin() {
        this.loading = true
		var that = this
		queryAccountList().then(response => {
        this.accountList = response
        console.log("AccountList")
        console.log(response)
		
		if (this.ruleForm.usertype =="供应商"){
			console.log("进入供应商")
			console.log("获取ID为：",this.accountList[2].accountId)
			this.$store.dispatch('account/login', this.accountList[2].accountId).then(() => {
			this.$router.push({ path: this.redirect || '/' })
			this.loading = false
			}).catch(() => {
			this.loading = false
			})
		}else{
			console.log("进入企业")
			this.$store.dispatch('account/login', this.accountList[0].accountId).then(() => {
			this.$router.push({ path: this.redirect || '/' })
			this.loading = false
			}).catch(() => {
			this.loading = false
			})
		}
    })
		//跳转企业供应商不同界面
		
     	
	}
       
    },
}
</script>